package com.devrik.freemockwalauidesign;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.devrik.freemockwalauidesign.Model.TestModel;
import com.devrik.freemockwalauidesign.others.API;
import com.devrik.freemockwalauidesign.others.APPCONSTANT;
import com.devrik.freemockwalauidesign.others.ShareHelper;
import com.devrik.freemockwalauidesign.others.Test_details_Adapter;
import com.google.android.material.button.MaterialButton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class AllTestCategoryActivity extends AppCompatActivity {

    ImageView img_back;
    MaterialButton btn_continue;
    public Context context = AllTestCategoryActivity.this;

    RecyclerView.LayoutManager layoutManager ;
    ArrayList<TestModel> testModelArrayList = new ArrayList<>();
    TestModel testModel = new TestModel();
    RecyclerView rvtestShow;

    String userid="";
    String Exam_Id="";
    String Test_id="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_test_category);

        img_back = findViewById(R.id.img_back);
        btn_continue = findViewById(R.id.btn_continue);

        userid =ShareHelper.getKey(AllTestCategoryActivity.this,APPCONSTANT.id);
        Log.e("fgg",userid);
        Exam_Id = ShareHelper.getKey(AllTestCategoryActivity.this, APPCONSTANT.exam_id);
        Test_id = ShareHelper.getKey(AllTestCategoryActivity.this,APPCONSTANT.test_id);

        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AllTestCategoryActivity.this,TestCategoryActivity.class));
                finish();
            }
        });

        btn_continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                TestDetails();


            }
        });
    }

    public void  TestDetails(){
        Log.e("fgg",userid);
        AndroidNetworking.post(API.showTestDetails)
                .addBodyParameter("id",userid)
                .addBodyParameter("exam_id",Exam_Id)
                .addBodyParameter("test_id",Test_id)
                .setTag("showTestDetails")
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("jcvzkxg",response.toString());
                        try {
                            if (response.getString("message").equals("successfull"))
                            {
                                JSONObject jsonObject = new JSONObject();

                                testModel.setId(jsonObject.getString("id"));
                                testModel.setId(jsonObject.getString("exam_id"));
                                testModel.setId(jsonObject.getString("test_id"));
                                testModel.setTest_Name(jsonObject.getString("test Name"));
                                testModel.setTime(jsonObject.getString("time"));
                                testModel.setTotal_marks(jsonObject.getString("total_marks"));
                                testModel.setTotal_question(jsonObject.getString("total_question"));
                                testModelArrayList.add(testModel);


                            }

                            rvtestShow.setHasFixedSize(true);
                            layoutManager = new LinearLayoutManager(AllTestCategoryActivity.this, RecyclerView.VERTICAL, false);
                            rvtestShow.setLayoutManager(layoutManager);
                            Test_details_Adapter adapter = new Test_details_Adapter(context,testModelArrayList);
                            rvtestShow.setAdapter(adapter);
                                Toast.makeText(AllTestCategoryActivity.this,""+response.getString("message"),Toast.LENGTH_SHORT).show();
                            }

                        catch (JSONException e) {
                            e.printStackTrace();
                            Log.e("dsjfgkj",e.getMessage());
                        }

                    }

                    @Override
                    public void onError(ANError anError) {
                        Log.e("ddfsaa",anError.getMessage());

                    }
                });

    }


}