package com.devrik.freemockwalauidesign.others;

public class APPCONSTANT {

    public static String id="id";
    public static String exam_id="exam_id";
    public static String test_id="test_id";
}
