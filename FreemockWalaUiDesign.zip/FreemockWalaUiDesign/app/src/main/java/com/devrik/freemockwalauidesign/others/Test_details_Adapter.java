package com.devrik.freemockwalauidesign.others;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.devrik.freemockwalauidesign.Model.TestModel;
import com.devrik.freemockwalauidesign.QuestionScreenActivity;
import com.devrik.freemockwalauidesign.R;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

public class Test_details_Adapter extends RecyclerView.Adapter<Test_details_Adapter.ViewHolder> {
    Context context;
    ArrayList<TestModel> testModelArrayList;

    public Test_details_Adapter(Context context, ArrayList<TestModel> testModelArrayList) {
        this.context = context;
        this.testModelArrayList = testModelArrayList;
    }

    @Override
    public Test_details_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.ssctests,parent,false);
        Test_details_Adapter.ViewHolder viewHolder=new Test_details_Adapter.ViewHolder(view);
        return viewHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull Test_details_Adapter.ViewHolder holder, int position) {

        TestModel  testmodel = testModelArrayList.get(position);

        if (!testmodel.equals("")) {
            holder.txt_test.setText(testmodel.getTestName());


            try { holder.btn_continue.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ShareHelper.putKey(context,APPCONSTANT.test_id);
                        context.startActivity(new Intent(context, QuestionScreenActivity.class));
                    }
                });



            } catch (Exception e) {
                e.printStackTrace();
                Log.e("dgfadf", e.getMessage());

            }


        }

    }

    @Override
    public int getItemCount() {
        return testModelArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txt_test;
        TextView ques;
        TextView marks;
        TextView min;
        MaterialButton btn_continue;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txt_test=itemView.findViewById(R.id.txt_test);
            ques = itemView.findViewById(R.id.ques);
            marks = itemView.findViewById(R.id.marks);
            min = itemView.findViewById(R.id.min);
            btn_continue = itemView.findViewById(R.id.btn_continue);

        }
    }


}
