package com.devrik.freemockwalauidesign;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.devrik.freemockwalauidesign.others.PageAdapter;
import com.google.android.material.tabs.TabItem;
import com.google.android.material.tabs.TabLayout;

public class ShowYourResultActivity extends AppCompatActivity {

    TabLayout tablayout1;
    TabItem tab1,tab2,tab3;
    ViewPager V_pager;
      PageAdapter pageAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_your_result);

        tablayout1 = (TabLayout)findViewById(R.id.tablayout1);
        tab1 = (TabItem)findViewById(R.id.tab1);
        tab2 = (TabItem)findViewById(R.id.tab2);
        tab3 = (TabItem)findViewById(R.id.tab3);
        V_pager =(ViewPager)findViewById(R.id.V_pager);

        pageAdapter = new PageAdapter(getSupportFragmentManager(),tablayout1.getTabCount());
        V_pager.setAdapter(pageAdapter);


        tablayout1.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                V_pager.setCurrentItem(tab.getPosition());

                if(tab.getPosition()==0||tab.getPosition()==1|| tab.getPosition()==2)
                    pageAdapter.notifyDataSetChanged();

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });


        V_pager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tablayout1));


    }
}