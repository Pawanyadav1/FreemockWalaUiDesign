package com.devrik.freemockwalauidesign;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.devrik.freemockwalauidesign.others.APPCONSTANT;
import com.devrik.freemockwalauidesign.others.ShareHelper;

public class SplashScreen extends AppCompatActivity {

    private Context context;
    String userid="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        userid = ShareHelper.getKey(SplashScreen.this, APPCONSTANT.id);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                if (userid.equals("1"))
                {
                    startActivity(new Intent(SplashScreen.this, SignInActivity.class));


                }else
                {
                    startActivity(new Intent(SplashScreen.this, HomeExamActivity.class));

                }


            }},500);
    }
}