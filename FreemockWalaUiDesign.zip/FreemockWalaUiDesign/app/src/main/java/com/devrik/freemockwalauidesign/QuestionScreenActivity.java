package com.devrik.freemockwalauidesign;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.devrik.freemockwalauidesign.others.API;
import com.devrik.freemockwalauidesign.others.APPCONSTANT;
import com.devrik.freemockwalauidesign.others.ShareHelper;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class QuestionScreenActivity extends AppCompatActivity {
   MaterialButton priview_btn,save_next_btn;
   Button submit_btn,clear_btn;
   ImageView back_btn;
    TabLayout tablayout1;
    String ExamID="",TestID="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

       ExamID = ShareHelper.getKey(QuestionScreenActivity.this, APPCONSTANT.exam_id);
       TestID = ShareHelper.getKey(QuestionScreenActivity.this,APPCONSTANT.test_id);
        setContentView(R.layout.activity_question_screen);
        priview_btn =findViewById(R.id.priview_btn);
        save_next_btn = findViewById(R.id.save_next_btn);
        submit_btn = findViewById(R.id.submit_btn);
        clear_btn = findViewById(R.id.clear_btn);
        back_btn = findViewById(R.id.back_btn);
        tablayout1 = findViewById(R.id.tablayout1);


        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(QuestionScreenActivity.this,TestCategoryActivity.class);
                startActivity(intent);
            }
        });

        tablayout1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                TestSection();

            }
        });

        submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(QuestionScreenActivity.this,ShowYourResultActivity.class);
                startActivity(intent);
            }
        });


    }

    public void TestSection(){
        AndroidNetworking.post(API.showTestSection)
                .addBodyParameter("exam_id",ExamID)
                .addBodyParameter("test_id",TestID)
                .setTag("TestSection")
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("section", response.toString());
                        try {
                            JSONArray jsonArray = new JSONArray(response.getString("data"));
                            for (int i = 0; i <jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);

                                Log.e("dsdsjdh",response.toString());



                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.e("dgfffdf", e.getMessage());
                        }

                    }

                    @Override
                    public void onError(ANError anError) {
                        Log.e("fhsdds", anError.getMessage());
                    }
                });


    }



}