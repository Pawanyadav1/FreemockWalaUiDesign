package com.devrik.freemockwalauidesign.others;

import android.content.Context;
import android.content.SharedPreferences;

import com.devrik.freemockwalauidesign.QuestionScreenActivity;
import com.devrik.freemockwalauidesign.SignUpActivity;

public class ShareHelper {
        private static SharedPreferences sharedPreferences;
        private static SharedPreferences.Editor editor;
        private static String MY_PREF = "MY_PREF";
    private static String Value;

    public static String putKey(Context context, String Key) {
            sharedPreferences = context.getSharedPreferences(MY_PREF, Context.MODE_PRIVATE);
            editor = sharedPreferences.edit();
            editor.putString(Key, Value);
            editor.commit();
            return Key;
        }

        public static String getKey(Context context, String Key) {

            sharedPreferences = context.getSharedPreferences(MY_PREF, Context.MODE_PRIVATE);
            return sharedPreferences.getString(Key, "");

        }

    public static void putKey(QuestionScreenActivity questionScreenActivity, String exam_id) {
    }

    public static void putkey(SignUpActivity signUpActivity, String id, String id1) {
    }
}

