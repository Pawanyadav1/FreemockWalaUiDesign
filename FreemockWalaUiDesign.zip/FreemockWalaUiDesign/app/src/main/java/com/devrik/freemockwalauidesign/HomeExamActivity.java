package com.devrik.freemockwalauidesign;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.devrik.freemockwalauidesign.others.API;
import com.devrik.freemockwalauidesign.others.APPCONSTANT;
import com.devrik.freemockwalauidesign.others.ShareHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class HomeExamActivity extends AppCompatActivity {

    ImageView im_go1,im_go,im_practice,bank1,bank2,logout;
    ImageView showBanner;
    TextView txt_show;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_exam);

        im_practice = findViewById(R.id.im_practice);
        im_go = findViewById(R.id.im_go);
        im_go1 = findViewById(R.id.im_go1);
        bank1 = findViewById(R.id.bank1);
        bank2 = findViewById(R.id.bank2);
        logout = findViewById(R.id.logout);
        txt_show = findViewById(R.id.txt_show);
        showBanner = findViewById(R.id.showBanner);

       show();
        im_practice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeExamActivity.this, ShowYourResultActivity.class);
                startActivity(intent);
            }
        });

        txt_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeExamActivity.this,ExamCategoryScreen.class));
                finish();
            }
        });

        im_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeExamActivity.this, ShowYourResultActivity.class);
                startActivity(intent);
            }
        });

        im_go1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeExamActivity.this, ShowYourResultActivity.class);
                startActivity(intent);
            }
        });
        bank1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeExamActivity.this, ExamCategoryScreen.class));
            }
        });
        bank2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeExamActivity.this, ExamCategoryScreen.class));
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    builder = new AlertDialog.Builder(HomeExamActivity.this, android.R.style.Theme_Material_Light_Dialog_Alert);
                } else {
                    builder = new AlertDialog.Builder(HomeExamActivity.this);
                }
                builder.setTitle(getResources().getString(R.string.app_name))
                        .setMessage("Are you sure you want to logout in the app")
                        .setPositiveButton(Html.fromHtml("<font color='#008037'>Ok</font>"), new DialogInterface.OnClickListener() {
                            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                            public void onClick(final DialogInterface dialog, int which) {
                                ShareHelper.putKey(HomeExamActivity.this, APPCONSTANT.id);
                                Intent intent = new Intent(HomeExamActivity.this, SignInActivity.class);
                                if(Build.VERSION.SDK_INT >= 11) {
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                } else {
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                }
                                startActivity(intent);
                            }
                        })
                        .setNegativeButton(Html.fromHtml("<font color='#008037'>Cancel</font>"), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .setIcon(R.drawable.ic_baseline_power_settings_new_24)
                        .show();
            }
        });

    }
        private void show(){
            AndroidNetworking.upload(API.showBanner)
                    .addMultipartParameter("image",showBanner.toString().trim())
                    .setTag("showBanner")
                    .setPriority(Priority.HIGH)
                    .build()
                    .getAsJSONObject(new JSONObjectRequestListener() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                JSONArray jsonArray = new JSONArray(response.getString("data"));
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                                }
                            }
                            catch (JSONException e) {
                                e.printStackTrace();
                                Log.e("dgfffdf", e.getMessage());
                            }
                        }
                        @Override
                        public void onError(ANError anError) {

                        }
                    });
        }
    }
