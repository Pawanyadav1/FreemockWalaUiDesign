package com.devrik.freemockwalauidesign.Model;

public class TestDetailModel {


}
