package com.devrik.freemockwalauidesign.others;

public class API {
    public static String BASEURL="https://www.freemockwala.com/api/process.php?action=";
    public static String signup=BASEURL+"signup";
    public static String signIn=BASEURL+"signIn";
    public static String showBanner=BASEURL+"showBanner";
    public static String showExam=BASEURL+"showExam";
    public static String showTest=BASEURL+"showTest";
    public static String showTestDetails=BASEURL+"showTestDetails";
    public static String showTestSection=BASEURL+"showTestSection";

}
