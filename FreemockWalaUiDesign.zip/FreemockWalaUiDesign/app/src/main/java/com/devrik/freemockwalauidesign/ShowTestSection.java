package com.devrik.freemockwalauidesign;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ShowTestSection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_test_section);
    }
}