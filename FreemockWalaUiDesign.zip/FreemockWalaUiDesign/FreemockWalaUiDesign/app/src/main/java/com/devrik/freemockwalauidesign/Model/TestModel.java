package com.devrik.freemockwalauidesign.Model;

public class TestModel {

    String id = "";
    String exam_id="";
    String testName="";
    String typingTest="";
    String typingTestApearance="";
    String free_paid="";
    String negative_mark="";
    String strtotime="";
    String image="";
    String path="";

    public String getImage(){
        return image;
    }
    public void setImage(String image) {
        this.image = image;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getExam_id() {
        return exam_id;
    }

    public void setExam_id(String exam_id) {
        this.exam_id = exam_id;
    }

    public String getTestName() {
        return testName;
    }

    public void setTestName(String testName) {
        this.testName = testName;
    }

    public String getTypingTest() {
        return typingTest;
    }

    public void setTypingTest(String typingTest) {
        this.typingTest = typingTest;
    }

    public String getTypingTestApearance() {
        return typingTestApearance;
    }

    public void setTypingTestApearance(String typingTestApearance) {
        this.typingTestApearance = typingTestApearance;
    }

    public String getFree_paid() {
        return free_paid;
    }

    public void setFree_paid(String free_paid) {
        this.free_paid = free_paid;
    }

    public String getNegative_mark() {
        return negative_mark;
    }

    public void setNegative_mark(String negative_mark) {
        this.negative_mark = negative_mark;
    }

    public String getStrtotime() {
        return strtotime;
    }

    public void setStrtotime(String strtotime) {
        this.strtotime = strtotime;
    }


}
