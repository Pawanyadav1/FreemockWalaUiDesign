package com.devrik.freemockwalauidesign.others;

public class APPCONSTANT {

    public static String USERID="id";
    public static String Email="email";
    public static String EXAM_ID="EXAM_ID";


}
