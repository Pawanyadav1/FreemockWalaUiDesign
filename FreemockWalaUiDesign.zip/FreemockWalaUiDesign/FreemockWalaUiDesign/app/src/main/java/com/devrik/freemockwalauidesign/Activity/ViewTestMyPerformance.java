package com.devrik.freemockwalauidesign.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.devrik.freemockwalauidesign.R;

public class ViewTestMyPerformance extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_test_my_performance);
    }
}