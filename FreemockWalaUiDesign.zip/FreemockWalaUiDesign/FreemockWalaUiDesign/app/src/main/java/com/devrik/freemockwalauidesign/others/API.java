package com.devrik.freemockwalauidesign.others;

public class API {
    public static String BASEURL="https://ruparnatechnology.com/freemockwala/api/process.php?action=";
    public static String signup=BASEURL+"signup";
    public static String signIn=BASEURL+"signIn";
    public static String showExam=BASEURL+"showExam";
    public static String showTest=BASEURL+"showTest";

}
