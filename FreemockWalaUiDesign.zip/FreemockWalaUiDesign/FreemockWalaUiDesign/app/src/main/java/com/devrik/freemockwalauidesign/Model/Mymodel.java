package com.devrik.freemockwalauidesign.Model;

public class Mymodel {

    String id = "",examName = "" ,examLogo = "",strtotime = "",path = "";

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getExamName() {
        return examName;
    }

    public void setExamName(String examName) {
        this.examName = examName;
    }

    public String getExamLogo() {
        return examLogo;
    }

    public void setExamLogo(String examLogo) {
        this.examLogo = examLogo;
    }

    public String getStrtotime() {
        return strtotime;
    }

    public void setStrtotime(String strtotime) {
        this.strtotime = strtotime;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;

    }

    public String getImage() {
        return getImage();

    }
}
